package com.Aula01 // Altere para o seu nome de pacote

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.Aula01.R

class MainActivity : AppCompatActivity() {

    private lateinit var timeInput: EditText
    private lateinit var startButton: Button
    private lateinit var timerText: TextView
    private var countDownTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializa os componentes do layout
        timeInput = findViewById(R.id.timeInput)
        startButton = findViewById(R.id.startButton)
        timerText = findViewById(R.id.timerText)

        startButton.setOnClickListener {
            val minutesStr = timeInput.text.toString()
            if (minutesStr.isNotEmpty()) {
                val minutes = minutesStr.toLong()
                startTimer(minutes * 60 * 1000) // Converte minutos para milissegundos
            } else {
                Toast.makeText(this, "Digite um tempo válido!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startTimer(timeMillis: Long) {
        countDownTimer?.cancel() // Cancela o timer atual, se houver um rodando

        countDownTimer = object : CountDownTimer(timeMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val minutes = millisUntilFinished / 1000 / 60
                val seconds = (millisUntilFinished / 1000) % 60
                timerText.text = String.format("%02d:%02d", minutes, seconds)
            }

            override fun onFinish() {
                timerText.text = "00:00"
                Toast.makeText(applicationContext, "Tempo finalizado!", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }
}
